export const fonts = {
  default: 'Roboto, sans-serif',
  code: 'monospace',
}
